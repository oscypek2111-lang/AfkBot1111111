# AFK Bot GUI — Minecraft 1.21.11 (Fabric)

Projekt zawiera:
- moda Fabric z GUI otwieranym klawiszem `Right Shift`,
- lokalny backend Node.js + Mineflayer, który łączy osobnego klienta-bota z serwerem,
- logowanie komendą `/login hasło` po dołączeniu,
- wysyłanie komend i status połączenia.

**Ważne:** to projekt źródłowy. Nie dołączam gotowego, przetestowanego JAR-a. Trzeba go zbudować lokalnie. Bot może być blokowany przez regulamin serwera; używaj go tylko tam, gdzie automatyczne AFK jest dozwolone.

## Wymagania
- Java JDK 21
- Minecraft Java 1.21.11 + Fabric Loader
- Node.js 20 lub nowszy
- połączenie z internetem przy pierwszym budowaniu / instalacji zależności

## 1. Uruchom backend bota
1. Zainstaluj Node.js.
2. Otwórz folder `backend`.
3. W terminalu uruchom:
   ```bash
   npm install
   npm start
   ```
4. Zostaw okno terminala otwarte. Backend nasłuchuje wyłącznie na `127.0.0.1:3000`.

## 2. Zbuduj moda
1. Otwórz folder główny projektu w IntelliJ IDEA albo terminalu.
2. Uruchom:
   ```bat
   gradlew.bat build
   ```
   Jeśli w paczce nie ma wrappera Gradle, otwórz projekt w IntelliJ IDEA i pozwól mu skonfigurować Gradle; następnie uruchom zadanie `build`.
3. Gotowy plik JAR powinien pojawić się w `build\libs\`.
4. Skopiuj JAR do folderu `.minecraft\mods`. Zainstaluj Fabric API dla Minecrafta 1.21.11, jeśli nie jest już zainstalowane.

## 3. Używanie
1. Uruchom Minecrafta profilem Fabric 1.21.11.
2. Upewnij się, że backend działa (`npm start`).
3. W świecie lub menu naciśnij `Right Shift`, aby otworzyć GUI.
4. Wpisz IP, port, nick i hasło do `/login`.
5. Kliknij `Połącz`. Bot zaloguje się jako osobny gracz w trybie offline/cracked.
6. W polu komendy wpisz np. `/tp TWÓJ_NICK` lub inną komendę dozwoloną na serwerze i kliknij `Wyślij`.
7. `Rozłącz` rozłącza bota.

## Uwagi i rozwiązywanie problemów
- To nie jest drugie konto premium. Działa tylko na serwerach, które akceptują logowanie offline/cracked.
- Nick musi być wolny. Jeśli serwer ma whitelistę, limit botów albo ochronę antybotową, połączenie może zostać odrzucone.
- Komenda teleportacji zależy od pluginów i uprawnień serwera.
- Hasło jest wysyłane tylko do lokalnego backendu `127.0.0.1`; nie jest zapisywane do pliku przez projekt.
- Jeśli bot nie łączy się, sprawdź komunikat w terminalu backendu.
- GUI pokazuje status backendu/bota; nie gwarantuje, że serwer zaakceptował komendę `/login`.
