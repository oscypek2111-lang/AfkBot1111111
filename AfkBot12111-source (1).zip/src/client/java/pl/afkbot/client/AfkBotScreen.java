package pl.afkbot.client;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

public class AfkBotScreen extends Screen {
    private static final Gson GSON = new Gson();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(2)).build();

    private EditBox host, port, nick, password, command;
    private String status = "Backend: nie sprawdzono";
    private String logs = "Uruchom backend w folderze backend: npm start";
    private int centerX;

    public AfkBotScreen() {
        super(Component.literal("AFK Bot GUI"));
    }

    @Override
    protected void init() {
        centerX = this.width / 2;
        int left = centerX - 155;
        int y = 42;
        host = field(left, y, 210, "IP serwera (np. play.example.pl)", "127.0.0.1"); y += 25;
        port = field(left + 220, y - 25, 90, "Port", "25565");
        nick = field(left, y, 150, "Nick bota", "AfkBot"); y += 25;
        password = field(left, y, 310, "Hasło do /login", ""); password.setMaxLength(128); password.setValue(""); y += 32;

        addRenderableWidget(Button.builder(Component.literal("Połącz"), b -> connect())
                .bounds(left, y, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Rozłącz"), b -> post("/disconnect", new JsonObject()))
                .bounds(left + 108, y, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Status"), b -> refreshStatus())
                .bounds(left + 216, y, 94, 20).build());

        y += 32;
        command = field(left, y, 220, "Komenda (np. /tp TwójNick)", ""); y += 25;
        addRenderableWidget(Button.builder(Component.literal("Wyślij komendę"), b -> sendCommand())
                .bounds(left, y, 130, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Zamknij"), b -> onClose())
                .bounds(left + 140, y, 90, 20).build());
        refreshStatus();
    }

    private EditBox field(int x, int y, int w, String hint, String initial) {
        EditBox box = new EditBox(this.font, x, y, w, 20, Component.literal(hint));
        box.setHint(Component.literal(hint));
        box.setValue(initial);
        addRenderableWidget(box);
        return box;
    }

    private void connect() {
        JsonObject data = new JsonObject();
        data.addProperty("host", host.getValue().trim());
        data.addProperty("port", parsePort());
        data.addProperty("username", nick.getValue().trim());
        data.addProperty("password", password.getValue());
        post("/connect", data);
    }

    private int parsePort() {
        try {
            int value = Integer.parseInt(port.getValue().trim());
            return Math.max(1, Math.min(65535, value));
        } catch (Exception ignored) {
            return 25565;
        }
    }

    private void sendCommand() {
        JsonObject data = new JsonObject();
        data.addProperty("command", command.getValue().trim());
        post("/command", data);
    }

    private void refreshStatus() {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:3000/status"))
                    .timeout(Duration.ofSeconds(2)).GET().build();
            HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject json = GSON.fromJson(response.body(), JsonObject.class);
            status = "Status: " + json.get("status").getAsString();
            logs = json.has("message") ? json.get("message").getAsString() : "Backend działa.";
        } catch (Exception e) {
            status = "Backend: offline";
            logs = "Uruchom backend: folder backend → npm start";
        }
    }

    private void post(String path, JsonObject data) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:3000" + path))
                    .timeout(Duration.ofSeconds(5))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(data), StandardCharsets.UTF_8))
                    .build();
            HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject json = GSON.fromJson(response.body(), JsonObject.class);
            status = "Status: " + (json.has("status") ? json.get("status").getAsString() : response.statusCode());
            logs = json.has("message") ? json.get("message").getAsString() : response.body();
        } catch (Exception e) {
            status = "Błąd połączenia z backendem";
            logs = "Sprawdź, czy działa npm start w folderze backend.";
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(this.font, "AFK BOT GUI", centerX, 15, 0xFFFFFF);
        graphics.drawString(this.font, "IP i port", centerX - 155, 29, 0xA0A0A0);
        graphics.drawString(this.font, "Nick i hasło", centerX - 155, 79, 0xA0A0A0);
        graphics.drawString(this.font, status, centerX - 155, this.height - 60, 0x55FF55);
        graphics.drawString(this.font, trim(logs, 54), centerX - 155, this.height - 45, 0xDDDDDD);
        graphics.drawString(this.font, "Bot jest osobnym połączeniem. Używaj zgodnie z regulaminem serwera.", centerX - 155, this.height - 28, 0xAAAAAA);
        super.render(graphics, mouseX, mouseY, delta);
    }

    private String trim(String value, int max) {
        if (value == null) return "";
        return value.length() > max ? value.substring(0, max - 3) + "..." : value;
    }

    @Override
    public void tick() {
        super.tick();
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }
}
