const express = require('express');
const mineflayer = require('mineflayer');

const app = express();
app.use(express.json({ limit: '16kb' }));

// Bind only to loopback. This API is intended for the local Minecraft mod only.
const HOST = '127.0.0.1';
const PORT = 3000;

let bot = null;
let state = 'Rozłączony';
let message = 'Backend działa.';

function reply(res, status = state, msg = message) {
  res.json({ status, message: msg });
}

app.get('/status', (_req, res) => reply(res));

app.post('/connect', (req, res) => {
  const { host, port, username, password } = req.body || {};
  if (typeof host !== 'string' || !host.trim() ||
      typeof username !== 'string' || !username.trim()) {
    return res.status(400).json({ status: 'Błąd', message: 'Wpisz IP serwera i nick.' });
  }
  if (bot) {
    try { bot.quit('Reconnect requested'); } catch (_) {}
    bot = null;
  }

  state = 'Łączenie...';
  message = `Łączenie z ${host.trim()}:${Number(port) || 25565}`;
  try {
    bot = mineflayer.createBot({
      host: host.trim(),
      port: Math.max(1, Math.min(65535, Number(port) || 25565)),
      username: username.trim(),
      auth: 'offline',
      version: '1.21.11',
      hideErrors: false
    });

    bot.once('login', () => {
      state = 'Połączony';
      message = `Bot ${bot.username} połączył się.`;
      // Send the server's login command after joining. Do not log the password.
      if (typeof password === 'string' && password.length > 0) {
        setTimeout(() => {
          if (bot && bot.player) {
            bot.chat(`/login ${password}`);
            state = 'Wysłano /login';
            message = 'Wysłano komendę logowania; sprawdź komunikaty serwera.';
          }
        }, 1200);
      }
    });

    bot.on('kicked', reason => {
      state = 'Wyrzucony';
      message = `Serwer wyrzucił bota: ${String(reason).slice(0, 180)}`;
      bot = null;
    });
    bot.on('end', reason => {
      state = 'Rozłączony';
      message = `Połączenie zakończone${reason ? ': ' + String(reason).slice(0, 120) : '.'}`;
      bot = null;
    });
    bot.on('error', err => {
      state = 'Błąd';
      message = String(err.message || err).slice(0, 200);
    });
    bot.on('messagestr', text => {
      const clean = String(text).replace(/§./g, '').slice(0, 180);
      if (clean) message = clean;
    });
    return reply(res, state, message);
  } catch (err) {
    bot = null;
    state = 'Błąd';
    message = String(err.message || err).slice(0, 200);
    return res.status(500).json({ status: state, message });
  }
});

app.post('/disconnect', (_req, res) => {
  if (bot) {
    try { bot.quit('Disconnected from AFK Bot GUI'); } catch (_) {}
    bot = null;
  }
  state = 'Rozłączony';
  message = 'Bot został rozłączony.';
  reply(res);
});

app.post('/command', (req, res) => {
  const command = req.body && req.body.command;
  if (!bot || !bot.player) {
    return res.status(409).json({ status: 'Rozłączony', message: 'Najpierw połącz bota.' });
  }
  if (typeof command !== 'string' || !command.trim()) {
    return res.status(400).json({ status: state, message: 'Wpisz komendę.' });
  }
  bot.chat(command.trim().startsWith('/') ? command.trim() : `/${command.trim()}`);
  state = 'Wysłano komendę';
  message = 'Komenda została wysłana.';
  reply(res);
});

app.listen(PORT, HOST, () => {
  console.log(`AFK Bot backend działa na http://${HOST}:${PORT}`);
  console.log('To API jest dostępne tylko lokalnie na tym komputerze.');
});
