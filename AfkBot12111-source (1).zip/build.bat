@echo off
chcp 65001 >nul
if not exist gradlew.bat (
  echo Brak gradlew.bat. Otworz projekt w IntelliJ IDEA i skonfiguruj Gradle Wrapper.
  pause
  exit /b 1
)
gradlew.bat build
pause
